import en from './en'
import cn from './cn'
import kr from './kr'
export default {
  en,
  cn,
  kr,
}
